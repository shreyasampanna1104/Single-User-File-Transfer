package CNproject;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileServer {
    private static final int PORT = 12345;
    private static final String AVAILABLE_DIR = "./available/";
    private static final String DOWNLOADED_DIR = "./downloaded/";

    private static List<String> getAvailableFiles() {
        List<String> fileList = new ArrayList<>();
        File directory = new File(AVAILABLE_DIR);

        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        fileList.add(file.getName());
                    }
                }
            }
        }

        return fileList;
    }

    private static class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (
                    DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
                    DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream())
            ) {
                // Send the list of available files to the client
                List<String> fileList = getAvailableFiles();
                dos.writeInt(fileList.size());
                for (String fileName : fileList) {
                    dos.writeUTF(fileName);
                }

                String selectedFile = dis.readUTF();
                File file = new File(AVAILABLE_DIR + selectedFile);

                if (file.exists()) {
                    dos.writeBoolean(true); // File exists

                    long progress = 0L;
                    if (fileProgress.containsKey(selectedFile)) {
                        progress = fileProgress.get(selectedFile);
                    }

                    dos.writeLong(progress); // Send the current progress to the client

                    try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
                        raf.seek(progress); // Move to the current progress position

                        byte[] buffer = new byte[4096];
                        int bytesRead;

                        while ((bytesRead = raf.read(buffer)) != -1) {
                            dos.write(buffer, 0, bytesRead);
                            progress += bytesRead;
                            fileProgress.put(selectedFile, progress);

                            // Simulate pausing for demonstration purposes
                            Thread.sleep(100);
                        }
                    }

                } else {
                    dos.writeBoolean(false); // File does not exist
                }

            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private static Map<String, Long> fileProgress = new HashMap<>();

    public static void main(String[] args) {
        // Create directories if they don't exist
        createDirectory(AVAILABLE_DIR);
        createDirectory(DOWNLOADED_DIR);

        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server is running and waiting for connections...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void createDirectory(String dirName) {
        File directory = new File(dirName);
        if (!directory.exists()) {
            if (directory.mkdirs()) {
                System.out.println("Directory created: " + dirName);
            } else {
                System.out.println("Failed to create directory: " + dirName);
            }
        }
    }
}
