package CNproject;
import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class FileClient {
    private static final int PORT = 12345;
    private static final String DOWNLOAD_DIR = "downloaded/";

    public static void main(String[] args) {
        try (
                Socket socket = new Socket("localhost", PORT);
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream())
        ) {
            // Receive the list of available files from the server
            int numFiles = dis.readInt();
            System.out.println("Available files on the server:");
            for (int i = 0; i < numFiles; i++) {
                System.out.println((i + 1) + ". " + dis.readUTF());
            }

            // Get user input for the file to download
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the number of the file to download: ");
            int selectedFileNumber = scanner.nextInt();
            String selectedFileName = "file" + selectedFileNumber + ".txt";

            dos.writeUTF(selectedFileName);

            if (dis.readBoolean()) {
                // File exists, start downloading
                long progress = 0L;

                File downloadDir = new File(DOWNLOAD_DIR);
                if (!downloadDir.exists()) {
                    downloadDir.mkdirs();
                }

                File file = new File(downloadDir, selectedFileName);
                if (file.exists()) {
                    progress = file.length();
                }

                dos.writeLong(progress); // Send the current progress to the server

                try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
                    raf.seek(progress); // Move to the current progress position

                    byte[] buffer = new byte[4096];
                    int bytesRead;

                    while ((bytesRead = dis.read(buffer)) != -1) {
                        raf.write(buffer, 0, bytesRead);
                        progress += bytesRead;

                        // Simulate pausing for demonstration purposes
                        Thread.sleep(100);
                    }

                    System.out.println("File downloaded successfully.");

                }
            } else {
                System.out.println("File does not exist on the server.");
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
